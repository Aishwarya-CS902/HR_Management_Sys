const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const HR = require('./models/HR');
const app = express();
const PORT = 5001;

mongoose.connect('mongodb://localhost:27017/HRdb', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the 'css' directory
app.use(express.static('css'));

app.get('/', async (req, res) => {
    const hr = await HR.find();
    res.render('index', { hr });
});

app.post('/save', async (req, res) => {
    const { employeeId, employeeName, employeeJob, employeeExperience, employeeSalary } = req.body;
    const hr = new HR({ employeeId, employeeName, employeeJob, employeeExperience, employeeSalary });
    await hr.save();
    res.redirect('/');
});

app.post('/delete/:id', async (req, res) => {
    await HR.findByIdAndDelete(req.params.id);
    res.redirect('/');
});

app.post('/update/:id', async (req, res) => {
    const { employeeId, employeeName, employeeJob, employeeExperience, employeeSalary } = req.body;
    await HR.findByIdAndUpdate(req.params.id, { employeeId, employeeName, employeeJob, employeeExperience, employeeSalary });
    res.redirect('/');
});

app.listen(PORT, () => console.log(`Server running on port: ${PORT}`));
