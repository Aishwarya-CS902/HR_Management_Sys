


const mongoose = require('mongoose')

const hrSchema = new mongoose.Schema({
    employeeId: String,
    employeeName: String, 
    employeeJob: String,
    employeeExperience: String,
    employeeSalary: String
})

module.exports = mongoose.model('HR', hrSchema )